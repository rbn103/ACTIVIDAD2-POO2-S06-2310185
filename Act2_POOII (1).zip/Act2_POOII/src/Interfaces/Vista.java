package Interfaces;

public interface Vista {
    void iniciar();
}
